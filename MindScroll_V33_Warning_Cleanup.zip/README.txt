MindScroll V33 — Warning Cleanup + Notification Shade Fix
==========================================================

This ZIP is a source patch, not a signed APK/AAB.

Base:
- Uses the V32 shade-preservation behavior: the interruption screen/video remains
  attached while the target app still has an application window; dismiss only
  after two checks find no target application window.
- Settings version is MindScroll V33 • Beta.
- Gradle versionCode = 7, versionName = 1.5.

Installation:
1. Back up D:\AndroidProjects\MindScroll.
2. Extract the ZIP into D:\AndroidProjects\MindScroll and allow replacement of the
   matching files. The ZIP contains two Kotlin files, AndroidManifest.xml,
   app/build.gradle.kts, and app/src/main/res/values/strings.xml.
3. Open Android Studio and select Build > Make Project.
4. In MindScroll Settings, enable System panel overlay and grant Display over other
   apps when Android asks.
5. Install the debug build and test Notifications, fully expanded Quick Settings,
   closing each panel, then pressing Home/opening another app.

Warnings:
- The build was compile-checked in CI against Android API 36 because that is the
  installed platform on the CI runner; this ZIP preserves the project's API 37
  compile/target settings.
- Some remaining Android Studio items may be style/inspection messages (redundant
  qualifiers, spelling, boolean-literal arguments). The AccessibilityService policy
  reminder is not a compiler warning: review the prominent disclosure, explicit
  consent, and Play Console accessibility declaration before release.
- This has not been tested on a physical Samsung S25 Ultra. Do not upload to Google
  Play until device behavior is confirmed.
