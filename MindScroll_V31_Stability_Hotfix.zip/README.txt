MindScroll V31 — Stability Fix (no-flicker system shade)
=======================================================

WHY THIS FIX EXISTS
The earlier patch could mistake MindScroll's own overlay package for a real app exit, dismiss the splash, retrigger the reminder, and vibrate repeatedly. This package avoids treating MindScroll's own overlay as an app exit. It does not toggle the splash's visibility in response to notification/Quick Settings events.

EXPECTED BEHAVIOR
- At the reminder time, show the motivational video once and keep it steady.
- When Android's notification shade or Quick Settings is pulled down, Android's system panel appears above the splash; MindScroll does not hide/re-show the splash.
- Closing the system panel reveals the same still-running motivational overlay.
- Going Home or to another real app dismisses the intervention rather than leaving it on the launcher.
- Settings label says "MindScroll V31 • Beta".
- Android version metadata is versionCode 6 / versionName 1.4.

INSTALL
1. Extract this ZIP into:
   D:\AndroidProjects\MindScroll
2. Allow Windows to replace these four files:
   app\src\main\java\com\akash\mindscroll\MindScrollAccessibilityService.kt
   app\src\main\java\com\akash\mindscroll\MainActivity.kt
   app\src\main\AndroidManifest.xml
   app\build.gradle.kts
3. Open Android Studio and click Build > Make Project.
4. Install/run the app.
5. Open MindScroll > Settings > System panel support > Allow system panel overlay.
6. Android Settings will open. Enable "Allow display over other apps" for MindScroll, then return.
7. Test the reminder. Pull down Quick Settings from the top-right and notifications from the top-left. The splash should remain steady behind the panel, not flicker.
8. Close the panel and confirm the same splash remains. Then press Home and confirm the splash closes.
9. Confirm Settings shows "MindScroll V31 • Beta".

IMPORTANT
This is a source patch only; it is not a signed APK/AAB. This source has been checked for the regression pattern and package contents, but it has NOT been compiled in this environment or tested on the S25 Ultra. Do not upload to Play Console until Android Studio builds successfully and you have completed the device tests.
The display-over-other-apps permission must be enabled for the system shade to appear above the splash. Without it, the fallback accessibility overlay may appear above System UI.
