MindScroll V31 - Stability Hotfix (no flicker)
=============================================

Changes:
- Removes the old hide/show loop that caused motivational splash flicker.
- Keeps the motivational video in one steady application-overlay window so Android system panels can appear above it.
- Filters MindScroll's own overlay from foreground checks to stop accidental immediate dismissal/retrigger loops.
- Closes the real intervention when the user leaves the target app (including Home), without treating MindScroll's own overlay as an app exit.
- Settings shows "MindScroll V31 • Beta".
- Version code 6 / version name 1.4.
- Includes the optional display-over-other-apps permission declaration and settings shortcut.

Install:
1. Extract this ZIP directly into D:\AndroidProjects\MindScroll.
2. Allow Windows to replace these four files:
   app\src\main\java\com\akash\mindscroll\MindScrollAccessibilityService.kt
   app\src\main\java\com\akash\mindscroll\MainActivity.kt
   app\src\main\AndroidManifest.xml
   app\build.gradle.kts
3. Open Android Studio and click Build > Make Project.
4. Install and run. Go to Settings > System panel support > Allow system panel overlay.
5. In Android Settings, enable "Allow display over other apps" for MindScroll, then return.
6. Trigger the motivational video. Pull Quick Settings down from the top-right and notifications from the top-left. The splash should stay steady behind each panel without flickering.
7. Close the panel; the same splash should remain. Press Home and confirm the intervention closes.
8. Confirm Settings displays "MindScroll V31 • Beta".
9. Only after these device tests pass, generate a NEW signed AAB and upload it to your existing closed-testing track.

Validation:
- The current V31 source passed an isolated Gradle assembleDebug build.
- This verifies source/build compatibility only; it does not replace testing on the S25 Ultra or another device.
- This ZIP contains source files, not a signed APK/AAB or signing key. Do not publish until the device tests pass.
