MindScroll V31 — Notification / Quick Settings Shade Fix

This ZIP contains a four-file patch. It does not include a built APK.

Install the patch:
1. Back up your D:\AndroidProjects\MindScroll project.
2. Extract this ZIP into D:\AndroidProjects\MindScroll\ and allow Windows to replace the four matching files.
3. Open Android Studio and wait for Gradle sync, then choose Build > Make Project.
4. In MindScroll Settings, open System panel support and tap Allow system panel overlay. In Android Settings, enable Display over other apps for MindScroll if prompted.
5. Install the debug build and test before publishing.

Expected behavior:
- Open the motivational interruption over Reels.
- Pull down Notifications or Quick Settings: Android's panel should cover the same interruption screen.
- Close the panel: the same interruption and video should still be there without tapping Play.
- Press Home or open a different app: the interruption should be dismissed rather than stay over that app.

Notes:
- The source compile is checked in CI with Android API 36 because API 37 is unavailable on that runner. The patch preserves the project's API 37 Gradle settings.
- This package has not been verified on a physical Samsung S25 Ultra. Test on-device before uploading it to Google Play.
