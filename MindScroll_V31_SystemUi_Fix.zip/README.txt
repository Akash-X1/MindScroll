MindScroll V31 — Android System UI overlay fix

HOW TO APPLY
1. Close Android Studio or leave the project open.
2. Extract this ZIP directly into:
   D:\AndroidProjects\MindScroll
3. Allow Windows to replace:
   app\src\main\java\com\akash\mindscroll\MindScrollAccessibilityService.kt
4. In app/build.gradle.kts, set:
   versionCode = 6
   versionName = "1.4"
   (This assumes your current V30 release used versionCode 5 / versionName 1.3.)
5. In Android Studio, click Build > Make Project and fix any build errors before installing.
6. Test the motivational intervention, pull down Quick Settings from the top-right, then notifications from the top-left. Confirm the panel is visible/usable and the splash returns when the panel closes.
7. If the tests pass, generate a newly signed Android App Bundle (AAB). The old V30 AAB does not contain this fix.

This ZIP contains only the replacement Kotlin file and this README. It does not include signing keys, a built APK/AAB, or a full Android Studio project. Source change is not claimed to be compiled or device-tested.
