MindScroll V31 — System UI layering and intervention lifecycle fix

WHAT THIS PATCH CHANGES
- Removes the hide/show loop that caused motivational splash flickering.
- Uses Android's application overlay layer so notifications and Quick Settings can appear above the motivational splash after permission is enabled.
- Dismisses the real intervention if the user leaves the target app, including Home.
- Shows "MindScroll V31 • Beta" on the Settings screen.
- Keeps the watch timer paused while the intervention is visible.
- Sets versionCode 6 and versionName 1.4.
- Declares the special display-over-other-apps permission.

HOW TO APPLY
1. Extract this ZIP directly into D:\AndroidProjects\MindScroll.
2. Allow Windows to replace these four files:
   app\src\main\java\com\akash\mindscroll\MindScrollAccessibilityService.kt
   app\src\main\java\com\akash\mindscroll\MainActivity.kt
   app\src\main\AndroidManifest.xml
   app\build.gradle.kts
3. Open Android Studio. Click Build > Make Project. Fix any errors before installing.
4. Run/install the app. Open MindScroll > Settings > System panel support > Allow system panel overlay.
5. In Android Settings, enable "Allow display over other apps" for MindScroll, then return to MindScroll.
6. Test: trigger the intervention, pull Quick Settings down from the top-right and notifications down from the top-left. The splash should stay steady underneath the system panel. Close the panel; the splash should remain.
7. While the intervention is active, go to Home or another app. The intervention should dismiss and not stay over Home.
8. Confirm Settings shows "MindScroll V31 • Beta".
9. After tests pass, generate a newly signed Android App Bundle (AAB) and upload it to your existing closed testing track. Do not upload the old V30 AAB.

This ZIP contains source files only. It does not include a signed APK/AAB or signing keys. The code has not been compiled or device-tested here.
