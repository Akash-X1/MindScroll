MindScroll V31 — System UI layering and intervention lifecycle fix

WHAT THIS PATCH CHANGES
- Removes the previous hide/show behavior that caused splash flicker.
- Uses an application overlay so Android's system shade can appear above the splash after overlay permission is enabled.
- Dismisses the real motivational intervention if the user leaves the target app, including Home.
- Shows "MindScroll V31 • Beta" on the Settings screen.
- Keeps the watch timer paused while the intervention is visible.

HOW TO APPLY
1. Extract this ZIP directly into D:\AndroidProjects\MindScroll.
2. Allow Windows to replace both Kotlin files:
   app\src\main\java\com\akash\mindscroll\MindScrollAccessibilityService.kt
   app\src\main\java\com\akash\mindscroll\MainActivity.kt
3. Open app\src\main\AndroidManifest.xml. Immediately after the opening <manifest ...> line, add:
   <uses-permission android:name="android.permission.SYSTEM_ALERT_WINDOW" />
   Do not remove other permissions or entries.
4. Open app\build.gradle.kts and set:
   versionCode = 6
   versionName = "1.4"
   (V30 was versionCode 5 / versionName 1.3; if your current console release differs, use the next unused code.)
5. Android Studio: Build > Make Project. Fix any build errors before installing.
6. Install/open the app. Go to Settings > System panel support > Allow system panel overlay, then enable "Allow display over other apps" for MindScroll in Android Settings.
7. Test: trigger the intervention, pull Quick Settings from the top-right and notifications from the top-left. The splash should remain steady underneath the system panel. Close the panel; the splash should remain.
8. While the intervention is active, go to Home or another app. The intervention should dismiss and not linger over Home.
9. After tests pass, generate a new signed AAB. Do not upload the old V30 AAB.

This ZIP contains source files only. It does not include a signed APK/AAB or signing keys. The code has not been compiled or device-tested here.
