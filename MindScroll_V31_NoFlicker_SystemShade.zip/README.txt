MindScroll V31 - Stable System Shade Fix
=========================================

Changes:
- Removes the hide/show loop that caused motivational splash flicker.
- Keeps the motivational video in a steady application-overlay window so Android notification/Quick Settings panels appear above it.
- Dismisses the intervention when leaving the target app, including Home; also cleans up a test intervention.
- Updates Settings to "MindScroll V31 • Beta".
- Sets versionCode 6 and versionName 1.4.
- Includes display-over-other-apps permission declaration and settings control.

Install:
1. Extract this ZIP directly into D:\AndroidProjects\MindScroll.
2. Allow Windows to replace all four files:
   app\src\main\java\com\akash\mindscroll\MindScrollAccessibilityService.kt
   app\src\main\java\com\akash\mindscroll\MainActivity.kt
   app\src\main\AndroidManifest.xml
   app\build.gradle.kts
3. In Android Studio, click Build > Make Project. Do not upload if it fails.
4. Install the app. Open Settings > System panel support > Allow system panel overlay.
5. Enable "Allow display over other apps" for MindScroll in Android Settings, then return to the app.
6. Trigger the motivational video. Pull Quick Settings from the top-right and notifications from the top-left. The splash should remain steady behind the panels without flicker.
7. Close the panel; the splash should remain. Go to Home; the intervention should dismiss.
8. Confirm Settings displays V31.
9. Only after build and device tests pass, generate a new signed AAB and upload it to closed testing.

This ZIP contains source only; no signed APK/AAB or signing key is included. It has not been compiled or device-tested here. The overlay permission must be enabled for the system panel to appear above the splash; without it, the service falls back to the accessibility overlay.
